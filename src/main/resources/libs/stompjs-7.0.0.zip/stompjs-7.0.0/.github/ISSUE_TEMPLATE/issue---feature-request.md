---
name: issue / feature request
about: Report an issue / feature request
title: ''
labels: ''
assignees: ''
---

Please see FAQs at https://stomp-js.github.io/faqs/2019/05/20/faqs.html before reporting.
