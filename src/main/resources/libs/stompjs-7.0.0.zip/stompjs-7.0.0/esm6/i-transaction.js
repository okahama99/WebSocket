export {};
//# sourceMappingURL=i-transaction.js.map