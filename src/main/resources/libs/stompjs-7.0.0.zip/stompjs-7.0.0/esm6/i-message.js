export {};
//# sourceMappingURL=i-message.js.map