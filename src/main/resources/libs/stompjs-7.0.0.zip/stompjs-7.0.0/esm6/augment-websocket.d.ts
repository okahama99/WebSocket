import { IStompSocket } from './types.js';
/**
 * @internal
 */
export declare function augmentWebsocket(webSocket: IStompSocket, debug: (msg: string) => void): void;
