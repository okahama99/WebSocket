// eslint-disable-next-line no-self-assign
document.domain = document.domain;
