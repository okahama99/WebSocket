'use strict';

require('./sockjs_server')(8081, {
	listenAddress: '127.0.0.1',
	port: 8081
});
